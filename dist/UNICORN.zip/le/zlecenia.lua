le = le or {}

-- le.zlecenia: śledzenie zleceń od NPC. samodzielny moduł UNICORN
-- (własne triggery/aliasy, własne triggery/aliasy, zapis JSON, panel Geyser).
-- Uwaga: kolorowe echo używa decho() (tagi <r,g,b>, reset to <r> a nie <reset>).
-- Treść etykiet Geyser to Qt rich text: bez flexbox/grid/position/transform,
-- justowanie dwóch kolumn robimy przez proste <table>.
-- le.zlecenia są kluczowane po ID lokacji NPC (nie po imieniu) — to samo NPC
-- bywa widoczne pod różnymi nazwami (np. przed/po przedstawieniu się).

le.zlecenia = le.zlecenia or {}
le.zlecenia.UI = le.zlecenia.UI or {}

le.zlecenia.config = {
    panel = {
        x = "-280px", width = 260, top = -560,
        window = { name = "LeZleceniaWindow", titleText = "UNICORN · zlecenia",
            x = "45%", y = "15%", width = "260px", height = "178px",
            dockPosition = "floating", autoDock = false, restoreLayout = true },
        headerHeight = 24, itemHeight = 44, footerHeight = 22, maxItems = 3,
        routeWidth = 78, deleteWidth = 48, actionHeight = 18, btnMargin = 6,
    },
    style = [[
        background-color: rgba(12, 14, 18, 220);
        border: none;
        border-left: 3px solid #D7A84D;
        border-radius: 0px;
        padding: 3px 8px;
        font-family: 'DejaVu Sans Mono', 'Consolas', monospace;
    ]],
    btnStyle = [[
        background-color: transparent;
        border: none;
        padding: 0px;
        font-family: 'DejaVu Sans Mono', 'Consolas', monospace;
    ]],
    -- Wspólna, semantyczna paleta UNICORN.
    colors = {
        accent = "#D7A84D", text = "#D8DBE2", bracket = "#D7A84D",
        brand = "#D7A84D", label = "#9A9FAA", npc = "#D8DBE2",
        value = "#D8DBE2", good_label = "#82C9A5", good = "#82C9A5",
        urgent_high = "#D98282", urgent_mid = "#D7AE5D", urgent_low = "#8FC9A3",
        muted = "#8B909A", muted_dim = "#666B75", danger_link = "#D98282",
    },
    -- Zegar Arkadii: godzina gry trwa 120 s rzeczywistych, minuta gry 2 s,
    -- a pełny dzień gry (24 godziny) trwa 2880 s, czyli 48 minut.
    real_seconds_per_game_hour = 120,
    real_seconds_per_game_minute = 2,
    real_seconds_per_game_day = 24 * 120,
    check_interval = 30,
}

local function rgb(hex)
    hex = hex:gsub("#", "")
    return tonumber(hex:sub(1, 2), 16) .. "," .. tonumber(hex:sub(3, 4), 16) .. "," .. tonumber(hex:sub(5, 6), 16)
end

-- decho tag helper: <r,g,b>text<r>  (decho's reset tag is <r>, not <reset>)
local function dc(hex, text)
    return string.format("<%s>%s<r>", rgb(hex), tostring(text))
end

local function epoch() return os.time() end

-- Formatowanie pozostałego czasu: "2d 07h" / "3h 58m" / "12m" ------------

function le.zlecenia.duration(seconds)
    seconds = math.max(0, math.floor(tonumber(seconds) or 0))
    local d = math.floor(seconds / 86400)
    local h = math.floor((seconds % 86400) / 3600)
    local m = math.floor((seconds % 3600) / 60)
    if d > 0 then return string.format("%dd %02dh", d, h) end
    if h > 0 then return string.format("%dh %02dm", h, m) end
    return string.format("%dm", m)
end

function le.zlecenia.compact_duration(seconds)
    seconds = math.max(0, math.floor(tonumber(seconds) or 0))
    local hours = math.floor(seconds / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    return string.format("%d:%02d", hours, minutes)
end

function le.zlecenia.urgency_color(seconds)
    if seconds == nil then return le.zlecenia.config.colors.muted end
    if seconds < 6 * 3600 then return le.zlecenia.config.colors.urgent_high end
    if seconds < 2 * 86400 then return le.zlecenia.config.colors.urgent_mid end
    return le.zlecenia.config.colors.urgent_low
end

-- Polskie liczebniki (odmiany używane po "sztuk"/"dni" itp.) --------------

le.zlecenia.numberWords = {
    ["jeden"] = 1, ["jednego"] = 1, ["jednej"] = 1, ["jedna"] = 1,
    ["dwa"] = 2, ["dwoch"] = 2, ["dwu"] = 2, ["dwie"] = 2,
    ["trzy"] = 3, ["trzech"] = 3,
    ["cztery"] = 4, ["czterech"] = 4,
    ["piec"] = 5, ["pieciu"] = 5,
    ["szesc"] = 6, ["szesciu"] = 6,
    ["siedem"] = 7, ["siedmiu"] = 7,
    ["osiem"] = 8, ["osmiu"] = 8,
    ["dziewiec"] = 9, ["dziewieciu"] = 9,
    ["dziesiec"] = 10, ["dziesieciu"] = 10,
    ["jedenascie"] = 11, ["jedenastu"] = 11,
    ["dwanascie"] = 12, ["dwunastu"] = 12,
    ["trzynascie"] = 13, ["trzynastu"] = 13,
    ["czternascie"] = 14, ["czternastu"] = 14,
    ["pietnascie"] = 15, ["pietnastu"] = 15,
    ["szesnascie"] = 16, ["szesnastu"] = 16,
    ["siedemnascie"] = 17, ["siedemnastu"] = 17,
    ["osiemnascie"] = 18, ["osiemnastu"] = 18,
    ["dziewietnascie"] = 19, ["dziewietnastu"] = 19,
    ["dwadziescia"] = 20, ["dwudziestu"] = 20,
    ["trzydziesci"] = 30, ["trzydziestu"] = 30,
    ["czterdziesci"] = 40, ["czterdziestu"] = 40,
    ["piecdziesiat"] = 50, ["piecdziesieciu"] = 50,
    ["szescdziesiat"] = 60, ["szescdziesieciu"] = 60,
    ["siedemdziesiat"] = 70, ["siedemdziesieciu"] = 70,
    ["osiemdziesiat"] = 80, ["osiemdziesieciu"] = 80,
    ["dziewiecdziesiat"] = 90, ["dziewiecdziesieciu"] = 90,
    ["sto"] = 100, ["stu"] = 100,
}

-- Jednostki, które warto skrócić w wyświetlanym tekście.
le.zlecenia.unitNormalize = {
    kilogramow = "kg", kilogram = "kg", kilogramy = "kg", kilograma = "kg",
}

-- Słowa "łączące", zawsze obecne w opisach zleceń, niezależne od słownika
-- uczonego z gry (rasy mówiące bez spacji, np. gnomy, potrzebują ich do
-- segmentacji zlepionego tekstu).
le.zlecenia.seedVocab = {
    "z", "o", "i", "kazda", "sztuke", "sztuk", "sztuki",
    "dzien", "dnia", "dni", "godzina", "godzine", "godziny", "godzin",
    "minuta", "minute", "minuty", "minut", "kilka",
    "kg", "srednich", "srednia", "srednie", "duzych", "duza", "duze", "malych", "mala", "male",
    "ciezkich", "ciezka", "ciezkie", "lekkich", "lekka", "lekkie", "przynajmniej", "sredniej",
    "jakosci", "chroniacych", "nogi", "rece", "tors",
}

-- Uczy słownik segmentacji na podstawie tekstu, który już mamy PODZIELONY
-- spacjami (normalne, nie-gnomie wiadomości) — budujemy słownik z realnych
-- zleceń, więc z czasem "gnomia mowa" rozszyfrowuje się sama.
function le.zlecenia.learn_words(text)
    if not text then return end
    le.zlecenia.data.vocab = le.zlecenia.data.vocab or {}
    local changed = false
    for w in text:gmatch("%a+") do
        w = w:lower()
        if #w > 1 and not le.zlecenia.data.vocab[w] then
            le.zlecenia.data.vocab[w] = true
            changed = true
        end
    end
    return changed
end

function le.zlecenia.build_dict()
    local dict = {}
    for w in pairs(le.zlecenia.numberWords) do dict[w] = true end
    for _, w in ipairs(le.zlecenia.seedVocab) do dict[w] = true end
    if le.zlecenia.data.vocab then
        for w in pairs(le.zlecenia.data.vocab) do dict[w] = true end
    end
    return dict
end

-- Segmentacja zlepionego (bez spacji) tekstu na słowa ze słownika, metodą
-- programowania dynamicznego z pamięcią podręczną (klasyczny "word break").
-- Preferuje najdłuższe dopasowanie na starcie. Zwraca nil, jeśli nie da się
-- podzielić w całości.
function le.zlecenia.segment(s, dict, memo)
    if s == "" then return {} end
    memo = memo or {}
    if memo[s] ~= nil then return memo[s] or nil end
    for i = #s, 1, -1 do
        local word = s:sub(1, i)
        if dict[word] then
            local rest = le.zlecenia.segment(s:sub(i + 1), dict, memo)
            if rest then
                local result = { word }
                for _, w in ipairs(rest) do result[#result + 1] = w end
                memo[s] = result
                return result
            end
        end
    end
    memo[s] = false
    return nil
end

-- Próbuje rozdzielić zlepiony (bez spacji) fragment tekstu gnomiej mowy na
-- słowa, zwraca (tekst_ze_spacjami, ok). Gdy się nie uda — zwraca oryginał
-- niezmieniony i ok=false (zlecenie i tak trafia na listę, tylko z surowym
-- opisem, do poprawienia ręcznie po nauczeniu słownika).
function le.zlecenia.desquash(text)
    if not text or text:find("%s") then return text, true end
    local dict = le.zlecenia.build_dict()
    local words = le.zlecenia.segment(text:lower(), dict)
    if not words then return text, false end
    return table.concat(words, " "), true
end

-- Sumuje WSZYSTKIE rozpoznane słowa-liczebniki w tekście (np. "dwudziestu
-- trzech" -> 23). Używane tam, gdzie tekst zawiera tylko liczbę.
function le.zlecenia.words_to_number(text)
    if not text then return nil end
    text = text:lower():gsub("-", " ")
    local sum, found = 0, false
    for w in text:gmatch("%S+") do
        local val = le.zlecenia.numberWords[w]
        if val then sum = sum + val; found = true end
    end
    if found then return sum end
    return tonumber(text)
end

le.zlecenia.deadlineUnits = {
    {
        name = "day",
        seconds = le.zlecenia.config.real_seconds_per_game_day,
        forms = { "dzien", "dnia", "dni" },
    },
    {
        name = "hour",
        seconds = le.zlecenia.config.real_seconds_per_game_hour,
        forms = { "godzina", "godzine", "godziny", "godzin" },
    },
    {
        name = "minute",
        seconds = le.zlecenia.config.real_seconds_per_game_minute,
        forms = { "minuta", "minute", "minuty", "minut" },
    },
}

-- Parsuje termin zlecenia w jednostkach czasu gry, np. "dzien", "dwa dni",
-- "24 godziny". Brak liczebnika przed jednostką oznacza jeden.
function le.zlecenia.parse_deadline_seconds(text)
    text = tostring(text or ""):lower()
    text = text:gsub("^%s+", ""):gsub("%s+$", "")
    text = text:gsub("[%.%,;:]+$", "")

    -- Nieprecyzyjne „kilka” liczymy zachowawczo jako trzy jednostki gry.
    -- Dla „kilka godzin” oznacza to 3 godziny gry = 360 s rzeczywistych.
    text = text:gsub("^kilka%s+", "3 ")

    for _, unit in ipairs(le.zlecenia.deadlineUnits) do
        for _, form in ipairs(unit.forms) do
            local count
            if text == form then
                count = 1
            else
                local count_text = text:match("^(.-)%s+" .. form .. "$")
                if count_text then count = le.zlecenia.words_to_number(count_text) end
            end
            if count and count > 0 then
                return count * unit.seconds, count, unit.name
            end
        end
    end
    return nil
end

-- Wyciąga ilość z opisu zlecenia: cyframi ("10 desek dębowych") albo
-- słownie ("dwudziestu czterech sztuk kasztanowca", "osiemdziesieciu kilogramow
-- miesa z zubra"). Zwraca (ilość, reszta_tekstu) — reszta ma znormalizowaną
-- jednostkę na początku, jeśli ją rozpoznaliśmy (kilogramow -> kg).
function le.zlecenia.extract_quantity(text)
    local qty, rest = text:match("^(%d+)%s+(.*)$")
    if not qty then
        local words = {}
        for w in text:gmatch("%S+") do words[#words + 1] = w end
        local sum, consumed = 0, 0
        for i, w in ipairs(words) do
            local val = le.zlecenia.numberWords[w:lower()]
            if val then sum = sum + val; consumed = i else break end
        end
        if consumed > 0 then
            qty = sum
            local restWords = {}
            for i = consumed + 1, #words do restWords[#restWords + 1] = words[i] end
            rest = table.concat(restWords, " ")
        end
    end
    if not qty then return nil, text end
    qty = tonumber(qty)
    local firstWord, remainder = rest:match("^(%a+)%s*(.*)$")
    if firstWord and le.zlecenia.unitNormalize[firstWord:lower()] then
        rest = le.zlecenia.unitNormalize[firstWord:lower()] .. (remainder ~= "" and (" " .. remainder) or "")
    end
    return qty, rest
end

-- Odpowiedź przy częściowej realizacji często zawiera wyłącznie jednostkę,
-- np. „sześciu sztuk”. Nie jest to nazwa nowego przedmiotu — pełny opis
-- („sztuk laku”) trzeba wtedy zachować z pierwotnego zlecenia.
local function has_item_after_unit(text)
    text = tostring(text or ""):match("^%s*(.-)%s*$") or ""
    local _, remainder = text:match("^(%S+)%s*(.*)$")
    return remainder ~= nil and remainder ~= ""
end

local function rebuild_order_what(order)
    if type(order) ~= "table" or not order.remainingQuantity then return false end
    if not order.itemName or order.itemName == "" then return false end

    local _, current_text = le.zlecenia.extract_quantity(order.what or "")
    if current_text ~= "" and has_item_after_unit(current_text) then return false end

    order.what = string.format("%d %s", order.remainingQuantity, order.itemName)
    return true
end

-- Zapis/odczyt danych JSON ------------------------------------------------

le.zlecenia.path = getMudletHomeDir() .. "/Zlecenia_data.json"
le.zlecenia.data = le.zlecenia.data or { orders = {}, completed = 0 }

function le.zlecenia.load()
    if not io.exists(le.zlecenia.path) then return end
    local file = io.open(le.zlecenia.path, "r")
    if not file then le.zlecenia.read_only = true; return end
    local content = file:read("*a")
    file:close()
    local ok, decoded = pcall(yajl.to_value, content)
    if ok and type(decoded) == "table" and type(decoded.orders or {}) == "table"
        and type(decoded.completed or 0) == "number" then
        le.zlecenia.data = decoded
        le.zlecenia.data.orders = le.zlecenia.data.orders or {}
        le.zlecenia.data.completed = le.zlecenia.data.completed or 0
        -- Napraw wpisy skrócone przez starszą wersję po częściowej dostawie.
        for _, order in pairs(le.zlecenia.data.orders) do
            rebuild_order_what(order)
        end
    else
        le.zlecenia.read_only = true
        le.zlecenia.output("Nieprawidlowy zapis zlecen; zapis wstrzymany, aby zachowac plik.")
    end
end

function le.zlecenia.save()
    if le.zlecenia.read_only then return false end
    local ok, err = le.storage.write_json(le.zlecenia.path, le.zlecenia.data)
    if not ok then le.zlecenia.output("Nie zapisano zlecen: " .. tostring(err)) end
    return ok
end

-- Komunikaty w oknie tekstowym --------------------------------------------

local function console_prefix()
    if le.ui and le.ui.prefix then
        le.ui.prefix("zlec")
    else
        decho(dc(le.zlecenia.config.colors.accent, "▎"))
        decho("  ")
    end
end

function le.zlecenia.output(message)
    if le.ui and le.ui.output then
        le.ui.output("zlec", message)
        return
    end
    console_prefix()
    decho(tostring(message or "") .. "\n")
end

-- Obsługa triggerów gry: zlecenia trzymane pod kluczem ID lokacji NPC -----

function le.zlecenia.handle_no_order()
    local npcName = matches[2]:gsub("%s*$", "")
    local roomID = getPlayerRoom()
    le.zlecenia.data.orders[tostring(roomID)] = {
        npc = npcName, status = "brak", lastSeen = os.date("%H:%M %d-%m-%Y"),
        roomName = getRoomName(roomID) or "-", roomID = roomID,
    }
    le.zlecenia.save()
    le.zlecenia.output(string.format("%s nie ma dla Ciebie żadnych zleceń.", dc(le.zlecenia.config.colors.npc, npcName)))
    le.zlecenia.UI.rebuild()
end

function le.zlecenia.new_order_core(npcName, orderType, orderDetails)
    le.zlecenia.learn_words(orderDetails)
    local quantity, rest = le.zlecenia.extract_quantity(orderDetails)
    local what = quantity and string.format("%d %s", quantity, rest) or orderDetails

    le.zlecenia.temp = {
        npc = npcName, type = orderType, what = what, itemName = rest,
        receivedAt = epoch(), initialQuantity = quantity, remainingQuantity = quantity,
        roomID = getPlayerRoom(),
    }
end

function le.zlecenia.handle_new_order()
    le.zlecenia.new_order_core(matches[2]:gsub("%s*$", ""), matches[3], matches[4])
end

function le.zlecenia.handle_new_order_gnome()
    local orderDetails, ok = le.zlecenia.desquash(matches[4])
    le.zlecenia.new_order_core(matches[2]:gsub("%s*$", ""), matches[3], orderDetails)
    if not ok then
        le.zlecenia.output(dc(le.zlecenia.config.colors.muted,
            "Gnomia mowa nie w pełni rozpoznana · /le.zlecenia slowo <słowo>"))
    end
end

function le.zlecenia.order_time_core(timePhrase)
    if not le.zlecenia.temp then
        le.zlecenia.output(dc(le.zlecenia.config.colors.urgent_high,
            "Brak tymczasowego zlecenia do aktualizacji."))
        return
    end
    le.zlecenia.learn_words(timePhrase)
    local order = le.zlecenia.temp
    local realSeconds = le.zlecenia.parse_deadline_seconds(timePhrase)
    local estimated = realSeconds == nil
    if estimated then
        realSeconds = le.zlecenia.config.real_seconds_per_game_day
            or (24 * (le.zlecenia.config.real_seconds_per_game_hour or 120))
    end

    local roomID = order.roomID or getPlayerRoom()
    order.roomID = roomID
    order.roomName = getRoomName(roomID) or "-"
    order.status = "aktywne"
    order.lastSeen = os.date("%H:%M %d-%m-%Y")

    order.deadlineText = timePhrase
    order.deadlineEstimated = estimated
    order.completionAt = order.receivedAt + realSeconds

    -- Ta sama lokacja = to samo zlecenie, nawet jeśli NPC pokazał się pod inną nazwą.
    le.zlecenia.data.orders[tostring(roomID)] = order
    le.zlecenia.save()

    local remaining = order.completionAt - epoch()
    echo("\n")
    if estimated then
        le.zlecenia.output(dc(le.zlecenia.config.colors.urgent_mid,
            "Nie rozpoznano terminu „" .. tostring(timePhrase) .. "” · przyjęto 1 dzień gry."))
    end
    le.zlecenia.output(string.format(
        "Dodano dostawę · %s · %s · %s",
        dc(le.zlecenia.config.colors.value, order.what),
        dc(le.zlecenia.config.colors.npc, order.npc),
        dc(le.zlecenia.urgency_color(remaining), le.zlecenia.duration(remaining))
    ))
    le.zlecenia.temp = nil
    le.zlecenia.UI.rebuild(true)
end

function le.zlecenia.handle_order_time()
    le.zlecenia.order_time_core(matches[3])
end

function le.zlecenia.handle_order_time_gnome()
    local timePhrase, ok = le.zlecenia.desquash(matches[3])
    le.zlecenia.order_time_core(timePhrase)
    if not ok then
        le.zlecenia.output(dc(le.zlecenia.config.colors.muted,
            "Gnomia mowa nie w pełni rozpoznana · /le.zlecenia slowo <słowo>"))
    end
end

function le.zlecenia.partial_order_core(npcName, remainingPhrase)
    local key = tostring(getPlayerRoom())
    local order = le.zlecenia.data.orders[key]
    if not order then
        le.zlecenia.output(string.format("Nie znaleziono zlecenia od %s do aktualizacji.", dc(le.zlecenia.config.colors.npc, npcName)))
        return
    end

    le.zlecenia.learn_words(remainingPhrase)
    local remainingQuantity, restText = le.zlecenia.extract_quantity(remainingPhrase)
    if not remainingQuantity then
        le.zlecenia.output(dc(le.zlecenia.config.colors.urgent_high, "Nie udało się rozpoznać pozostałej ilości."))
        return
    end

    order.npc = npcName -- aktualizujemy do najnowszej nazwy NPC
    order.remainingQuantity = remainingQuantity
    order.lastSeen = os.date("%H:%M %d-%m-%Y")
    local itemText = restText
    if itemText == "" or not has_item_after_unit(itemText) then
        itemText = order.itemName or itemText
    end
    order.what = string.format("%d %s", remainingQuantity, itemText)

    -- Uwaga: ukończenie zlecenia zgłasza WYŁĄCZNIE osobny komunikat gry
    -- ("Dziekuje, wiecej mi juz nie trzeba.") — częściowa dostawa nigdy nie
    -- zalicza zlecenia jako wykonane, nawet gdy zejdzie do zera.
    le.zlecenia.output(string.format("Zaktualizowano zlecenie od %s. Pozostało: %s.", dc(le.zlecenia.config.colors.npc, npcName), dc(le.zlecenia.config.colors.value, order.what)))
    le.zlecenia.save()
    le.zlecenia.UI.rebuild()
end

function le.zlecenia.handle_partial_order()
    le.zlecenia.partial_order_core(matches[2]:gsub("%s*$", ""), matches[3])
end

function le.zlecenia.handle_partial_order_gnome()
    local remainingPhrase, ok = le.zlecenia.desquash(matches[3])
    le.zlecenia.partial_order_core(matches[2]:gsub("%s*$", ""), remainingPhrase)
    if not ok then
        le.zlecenia.output(dc(le.zlecenia.config.colors.muted,
            "Gnomia mowa nie w pełni rozpoznana · /le.zlecenia slowo <słowo>"))
    end
end

function le.zlecenia.handle_order_completed()
    local npcName = matches[2]:gsub("%s*$", "")
    local key = tostring(getPlayerRoom())
    if le.zlecenia.data.orders[key] then
        le.zlecenia.data.orders[key] = nil
        le.zlecenia.data.completed = le.zlecenia.data.completed + 1
        le.zlecenia.save()
        le.zlecenia.output(string.format("Zlecenie od %s zostało wykonane. Usunięto z listy.", dc(le.zlecenia.config.colors.npc, npcName)))
        le.zlecenia.output(string.format("%s %s", dc(le.zlecenia.config.colors.good_label, "Łącznie wykonanych zleceń:"), dc(le.zlecenia.config.colors.good, le.zlecenia.data.completed)))
    else
        le.zlecenia.output(string.format("Nie znaleziono zlecenia od %s na liście.", dc(le.zlecenia.config.colors.npc, npcName)))
    end
    le.zlecenia.UI.rebuild()
end

-- Automatyczne wygasanie ---------------------------------------------------

function le.zlecenia.check_expired()
    local now = epoch()
    local changed = false
    for key, order in pairs(le.zlecenia.data.orders) do
        if order.completionAt and order.completionAt <= now then
            le.zlecenia.data.orders[key] = nil
            changed = true
            le.zlecenia.output(string.format("Zlecenie na %s od %s właśnie się zakończyło. Usunięto z listy.",
                dc(le.zlecenia.config.colors.value, order.what or "-"), dc(le.zlecenia.config.colors.npc, order.npc)))
        end
    end
    if changed then le.zlecenia.save() end
end

-- Lista aktywnych zleceń, posortowana po najbliższym terminie ------------
-- Każdy wpis niesie swój klucz (order.key) do usuwania/rozwijania/tras.

function le.zlecenia.active_orders_sorted()
    local list = {}
    for key, order in pairs(le.zlecenia.data.orders) do
        if order.status ~= "brak" and (not order.completionAt or order.completionAt > epoch()) then
            order.key = key
            list[#list + 1] = order
        end
    end
    table.sort(list, function(a, b)
        local at, bt = a.completionAt or math.huge, b.completionAt or math.huge
        if at == bt then return tostring(a.key) < tostring(b.key) end
        return at < bt
    end)
    return list
end

-- Komendy konsolowe --------------------------------------------------------

function le.zlecenia.show_help()
    le.zlecenia.output("Pomoc · dostawy od NPC")
    le.zlecenia.output("Panel: 3 sloty, strony ‹/›. Kliknij dostawę po szczegóły i akcje w konsoli.")
    if le.ui and le.ui.note then
        le.ui.note("zlec", "Kliknij komendę, aby ją uruchomić.")
        le.ui.command("zlec", "/le.zlecenia okno", "/le.zlecenia okno", "przywroc okno zlecen na ekran", false)
        le.ui.command("zlec", "/le.zlecenia lista", "/le.zlecenia lista", "aktywne dostawy i szczegóły", false)
        le.ui.command("zlec", "/le.zlecenia sprawdz", "/le.zlecenia sprawdz", "zapytaj NPC o nowe zlecenie", false)
        le.ui.command("zlec", "/le.zlecenia usun <nr>", "/le.zlecenia usun ", "usuń dostawę z listy", true)
        le.ui.command("zlec", "/le.zlecenia reset", "/le.zlecenia reset", "wyczyść listę dostaw", false)
        le.ui.command("zlec", "/le.zlecenia slowo <słowo>", "/le.zlecenia slowo ", "uzupełnij słownik gnomiej mowy", true)
        le.ui.output("zlec", "Wykonane dostawy · " .. tostring(le.zlecenia.data.completed))
    end
end

function le.zlecenia.show_list()
    local col = le.zlecenia.config.colors
    local orders = le.zlecenia.active_orders_sorted()
    local no_order_npcs = {}
    for _, order in pairs(le.zlecenia.data.orders) do
        if order.status == "brak" then
            no_order_npcs[#no_order_npcs + 1] = { npc = order.npc, lastSeen = order.lastSeen }
        end
    end

    if #orders == 0 and #no_order_npcs == 0 then
        le.zlecenia.output("Nie masz aktualnie żadnych dostaw.")
        return
    end

    le.zlecenia.output("Aktywne dostawy · " .. tostring(#orders))
    le.zlecenia.indexMap = {}
    for index, order in ipairs(orders) do
        le.zlecenia.indexMap[index] = order.key
        le.zlecenia.show_order(order.key)
    end

    for _, item in ipairs(no_order_npcs) do
        console_prefix()
        decho(string.format("%s %s\n",
            dc(col.muted, item.npc or "-"),
            dc(col.muted_dim, "· brak zlecenia · " .. (item.lastSeen or "-"))))
    end
end

function le.zlecenia.show_order(key)
    local order = le.zlecenia.data.orders[key]
    if not order or order.status == "brak" then return end
    local col = le.zlecenia.config.colors
    local remaining = math.max(0, (order.completionAt or 0) - epoch())

    console_prefix()
    decho(string.format("%s  %s\n",
        dc(col.value, order.what or "-"),
        dc(le.zlecenia.urgency_color(remaining), le.zlecenia.duration(remaining))))

    console_prefix()
    decho(string.format("%s %s  %s %s  ",
        dc(col.muted, "Odbiorca ·"), dc(col.text, order.npc or "-"),
        dc(col.muted, "Miejsce ·"), dc(col.text, order.roomName or "-")))
    dechoLink(dc(col.good, le.zlecenia.UI.routingKey == order.key and "ZATRZYMAJ" or "PROWADŹ"),
        function()
            local current = le.zlecenia.data.orders[key]
            if current and (not current.completionAt or current.completionAt > epoch()) then le.zlecenia.UI.toggle_route(current) end
        end, "Prowadzenie do odbiorcy", true)
    decho("  ")
    dechoLink(dc(col.danger_link, "USUŃ"),
        function() le.zlecenia.remove_order(key) end, "Usuń tę dostawę", true)
    decho("\n")
end

function le.zlecenia.remove_by_index(index)
    local key = le.zlecenia.indexMap and le.zlecenia.indexMap[index]
    le.zlecenia.remove_order(key)
end

function le.zlecenia.remove_order(key)
    local order = key and le.zlecenia.data.orders[key]
    if order then
        if le.zlecenia.UI.routingKey == key then
            pcall(alias_func_prowadz_stop)
            le.zlecenia.UI.routingKey = nil
        end
        le.zlecenia.data.orders[key] = nil
        le.zlecenia.save()
        le.zlecenia.output(string.format("Zlecenie od %s zostało usunięte.", dc(le.zlecenia.config.colors.npc, order.npc)))
    else
        le.zlecenia.output("Nie znaleziono zlecenia do usunięcia.")
    end
    le.zlecenia.UI.rebuild()
end

function le.zlecenia.reset_all()
    le.zlecenia.data.orders = {}
    le.zlecenia.save()
    le.zlecenia.output(dc(le.zlecenia.config.colors.urgent_high, "Wszystkie zlecenia zostały usunięte."))
    le.zlecenia.UI.rebuild()
end

-- Panel na ekranie (Geyser), pod modułami czasu UNICORN -----------------------
-- Etykiety Geyser renderują Qt rich text (podzbiór HTML4/CSS2): brak
-- flexbox/grid/position/transform. Justowanie dwóch kolumn -> <table>.
-- Trzy stale sloty; szczegoly i akcje sa wypisywane w glownej konsoli.

-- UTF-8-safe shortening: full descriptions remain available in the console.
local function short_text(value, limit)
    local chars = {}
    for char in tostring(value or "-"):gmatch("[%z\1-\127\194-\244][\128-\191]*") do chars[#chars + 1] = char end
    if #chars > limit then return table.concat(chars, "", 1, limit - 1) .. "…" end
    return table.concat(chars)
end
local function esc(value)
    return tostring(value):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;")
end
function le.zlecenia.UI.order_html(order)
    local col = le.zlecenia.config.colors
    if not order then return "<span style='color:" .. col.muted_dim .. "'>—</span>" end
    local remaining = order.completionAt and math.max(0, order.completionAt - epoch())
    return string.format([[<div style='font-size:11px;color:%s'><b>%s</b></div>
        <div style='font-size:10px;color:%s'>%s &nbsp; <span style='color:%s'>%s</span></div>]],
        col.text, esc(short_text(order.what, 32)), le.zlecenia.urgency_color(remaining),
        remaining and le.zlecenia.compact_duration(remaining) or "?:??",
        col.muted, esc(short_text(order.roomName, 23)))
end

function le.zlecenia.UI.ensure_pool()
    if le.zlecenia.UI.pool then return end
    local ui = le.zlecenia.UI
    local p = le.zlecenia.config.panel
    local col = le.zlecenia.config.colors
    local parent
    if Geyser and Geyser.UserWindow and type(Geyser.UserWindow.new) == "function" then
        local options = {}
        for key, value in pairs(p.window) do options[key] = value end
        options.hidden = not ui.recovering
        if ui.recovering then options.restoreLayout = false; options.x = 80; options.y = 80 end
        local ok, window = pcall(function() return Geyser.UserWindow:new(options) end)
        if not ok then ui.window_error = tostring(window) end
        if ok and window then
            ui.window_error = nil
            ui.window = window
            parent = window
            if type(resizeWindow) == "function" then pcall(resizeWindow, p.window.name, 260, 178) end
            if type(setBackgroundColor) == "function" then
                -- Przezroczyste tlo konsoli. Powierzchnia natywnego Qt moze
                -- nadal byc nieprzezroczysta (zalezy od Mudleta i Windows).
                pcall(setBackgroundColor, p.window.name, 0, 0, 0, 0)
            end
        end
    end
    if not parent and Geyser and Geyser.UserWindow then
        ui.window_error = ui.window_error or "konstruktor UserWindow nie zwrocil okna"
        le.zlecenia.output("Nie mozna utworzyc okna zlecen: " .. ui.window_error)
    end
    ui.pool, ui.routeBtn, ui.deleteBtn, ui.slotOrder = {}, {}, {}, {}
    ui.mode = parent and "window" or "legacy"

    local function pos(x, y)
        if parent then return tostring(x) .. "px", tostring(y) .. "px" end
        return p.x, tostring(p.top + y) .. "px"
    end
    local hx, hy = pos(0, 0)
    ui.header = Geyser.Label:new({
        name = "LeZleceniaHeader", x = hx, y = hy,
        width = parent and "100%" or tostring(p.width) .. "px",
        height = tostring(p.headerHeight) .. "px",
    }, parent)
    ui.header:setStyleSheet(string.format([[
        background-color: rgba(12, 14, 18, 220);
        border:none; border-left:3px solid %s; padding:2px 8px;
        font-family:'DejaVu Sans Mono','Consolas',monospace;
    ]], col.accent))
    ui.header:setClickCallback(function() le.zlecenia.show_list() end)

    for i = 1, p.maxItems do
        local slot = i
        local x, y = pos(0, p.headerHeight)
        local label = Geyser.Label:new({
            name = "LeZleceniaItem" .. slot, x = x, y = y,
            width = parent and "100%" or tostring(p.width) .. "px",
            height = tostring(p.itemHeight) .. "px",
        }, parent)
        label:setStyleSheet(le.zlecenia.config.style)
        label:hide()
        label:setClickCallback(function()
            local order = le.zlecenia.UI.slotOrder[slot]
            if order then le.zlecenia.UI.toggle(order.key) end
        end)
        ui.pool[slot] = label
    end

    ui.nav = {}
    for i, caption in ipairs({ "‹", "›" }) do
        local direction = i == 1 and -1 or 1
        local x, y = pos(0, p.headerHeight + 3 * p.itemHeight)
        local button = Geyser.Label:new({name = "LeZleceniaPage" .. i,
            x = parent and (i == 1 and "0px" or "230px") or (i == 1 and p.x or "-50px"),
            y = y, width = "30px", height = "22px"}, parent)
        button:setStyleSheet(le.zlecenia.config.btnStyle)
        button:echo("<center><span style='color:" .. col.accent .. "'>" .. caption .. "</span></center>")
        button:setClickCallback(function()
            ui.page = math.max(1, math.min(ui.pages or 1, (ui.page or 1) + direction))
            ui.rebuild()
        end)
        ui.nav[i] = button
    end
    local x, y = pos(0, p.headerHeight + 3 * p.itemHeight)
    ui.footer = Geyser.Label:new({name = "LeZleceniaFooter", x = parent and "30px" or "-250px",
        y = y, width = "200px", height = "22px"}, parent)
    ui.footer:setStyleSheet(le.zlecenia.config.btnStyle)
end

-- Compatibility entry points no longer expand the card.
function le.zlecenia.UI.toggle(key) le.zlecenia.show_order(key) end
function le.zlecenia.UI.collapse_all() le.zlecenia.UI.rebuild() end
function le.zlecenia.UI.toggle_panel() le.zlecenia.show_list() end

function le.zlecenia.UI.toggle_route(order)
    if le.zlecenia.UI.routingKey == order.key then
        pcall(alias_func_prowadz_stop)
        le.zlecenia.UI.routingKey = nil
    else
        if le.zlecenia.UI.routingKey then pcall(alias_func_prowadz_stop) end
        le.zlecenia.UI.routingKey = nil
        local ok, result = pcall(alias_func_prowadz, order.roomID)
        if ok and result ~= false then
            le.zlecenia.UI.routingKey = order.key
        else
            le.zlecenia.output("Nie udalo sie uruchomic prowadzenia do odbiorcy.")
        end
    end
    le.zlecenia.UI.rebuild()
end

function le.zlecenia.UI.rebuild(force_show)
    if not (Geyser and Geyser.Label) then return end
    le.zlecenia.UI.ensure_pool()
    local ui, p = le.zlecenia.UI, le.zlecenia.config.panel
    local orders = le.zlecenia.active_orders_sorted()
    ui.pages = math.max(1, math.ceil(#orders / 3))
    ui.page = math.max(1, math.min(ui.page or 1, ui.pages))
    local visible = #orders > 0
    local action = visible and "show" or "hide"
    local needs_visibility = ui.visible ~= visible or (visible and force_show)
    if visible and type(windowVisible) == "function" then
        local ok, shown = pcall(windowVisible, p.window.name)
        if ok and shown == false then needs_visibility = true end
    end
    local visibility_ok = true
    if ui.window and needs_visibility then
        -- Reopen the existing native dock without restoring a stale saved layout.
        if visible and type(openUserWindow) == "function" then
            local ok, result = pcall(openUserWindow, p.window.name, false, false)
            visibility_ok = ok and result ~= false
        end
        if type(ui.window[action]) == "function" then pcall(ui.window[action], ui.window) end
        local native = visible and showWindow or hideWindow
        if type(native) == "function" then
            local ok, result = pcall(native, p.window.name)
            visibility_ok = visibility_ok and ok and result ~= false
        end
    end
    -- Failed native calls must be retried by the next refresh.
    if visibility_ok then ui.visible = visible else ui.visible = nil end
    ui.header:echo(string.format("<span style='color:%s'>ZLECENIA <b>%d</b></span>",
        le.zlecenia.config.colors.accent, #orders))
    ui.header[action](ui.header)
    ui.footer:echo(string.format("<center><span style='color:%s'>%d / %d</span></center>", le.zlecenia.config.colors.muted, ui.page, ui.pages))
    ui.footer[action](ui.footer)
    for _, button in ipairs(ui.nav) do button[action](button) end
    for i = 1, 3 do
        local order = orders[(ui.page - 1) * 3 + i]
        ui.slotOrder[i] = order
        local label = ui.pool[i]
        label:move(ui.mode == "window" and "0px" or p.x,
            tostring((ui.mode == "window" and 0 or p.top) + p.headerHeight + (i - 1) * p.itemHeight) .. "px")
        label:echo(ui.order_html(order))
        label[action](label)
    end
end

-- Explicit recovery for a saved off-screen/closed native window.
function le.zlecenia.UI.recover_window()
    if #le.zlecenia.active_orders_sorted() == 0 then
        le.zlecenia.output("Brak aktywnych zlecen; okno pozostaje ukryte.")
        return
    end
    local ui = le.zlecenia.UI
    ui.recovering = true
    local ok, err = pcall(function() ui.destroy(); ui.rebuild(true) end)
    ui.recovering = nil
    if ok then
        ok, err = le.ui.restore_window(ui.window, le.zlecenia.config.panel.window.name, 260, 178)
    end
    if not ok then
        le.zlecenia.output("Nie udalo sie przywrocic okna zlecen: " .. tostring(err))
        return false
    end
    le.zlecenia.output("Przywrocono okno zlecen na ekran.")
    return true
end

-- Triggery gry --------------------------------------------------------------

function le.zlecenia.setup_triggers()
    le.zlecenia.triggers = le.zlecenia.triggers or {}
    le.zlecenia.triggers.brak = tempRegexTrigger(
        "^(.+)\\s+\\w+\\s+do\\s+ciebie:\\s+Nie, w tej chwili niczego mi nie trzeba\\. Zajrzyj moze za jakis czas\\.$",
        [[le.zlecenia.handle_no_order()]]
    )
    le.zlecenia.triggers.nowe = tempRegexTrigger(
        "^(.+)\\s+\\w+\\s+do\\s+ciebie:\\s+Tak, mam pewne pilne zamowienie na (\\w+)\\. Potrzebuje (.+)\\. Dobrze zaplace.*$",
        [[le.zlecenia.handle_new_order()]]
    )
    le.zlecenia.triggers.czas = tempRegexTrigger(
        "^(.+)\\s+\\w+\\s+do\\s+ciebie:\\s+Na realizacje zamowienia mam (.+), pozniej zapewne bede potrzebowac czego innego\\.$",
        [[le.zlecenia.handle_order_time()]]
    )
    le.zlecenia.triggers.ukonczone = tempRegexTrigger(
        "^(.+)\\s+\\w+\\s+do\\s+ciebie:\\s+Dziekuje, wiecej mi juz nie trzeba\\.$",
        [[le.zlecenia.handle_order_completed()]]
    )
    le.zlecenia.triggers.czesciowe = tempRegexTrigger(
        "^(.+)\\s+\\w+\\s+do\\s+ciebie:\\s+Dziekuje, potrzebuje jeszcze (.+)\\.$",
        [[le.zlecenia.handle_partial_order()]]
    )

    -- Warianty "gnomiej mowy": ta sama struktura zdania, ale bez spacji
    -- (prefiks "... do ciebie:" zostaje normalny, tylko treść jest zlepiona).
    le.zlecenia.triggers.brak_gnom = tempRegexTrigger(
        "^(.+)\\s+\\w+\\s+do\\s+ciebie:\\s+Nie,wtejchwiliniczegominietrzeba\\.Zajrzyjmozezajakiscczas\\.$",
        [[le.zlecenia.handle_no_order()]]
    )
    le.zlecenia.triggers.nowe_gnom = tempRegexTrigger(
        "^(.+)\\s+\\w+\\s+do\\s+ciebie:\\s+Tak,mampewnepilnezamowienienam*na(\\w+)\\.Potrzebuje(.+)\\.Dobrzezaplace.*$",
        [[le.zlecenia.handle_new_order_gnome()]]
    )
    le.zlecenia.triggers.czas_gnom = tempRegexTrigger(
        "^(.+)\\s+\\w+\\s+do\\s+ciebie:\\s+Narealizacjezamowieniamam(.+),pozniejzapewnebedepotrzebowacczegoinnego\\.$",
        [[le.zlecenia.handle_order_time_gnome()]]
    )
    le.zlecenia.triggers.ukonczone_gnom = tempRegexTrigger(
        "^(.+)\\s+\\w+\\s+do\\s+ciebie:\\s+Dziekuje,wiecejmijuznietrzeba\\.$",
        [[le.zlecenia.handle_order_completed()]]
    )
    le.zlecenia.triggers.czesciowe_gnom = tempRegexTrigger(
        "^(.+)\\s+\\w+\\s+do\\s+ciebie:\\s+Dziekuje,potrzebujejeszcze(.+)\\.$",
        [[le.zlecenia.handle_partial_order_gnome()]]
    )
end

-- Aliasy: /le.zlecenia ... ---------------------------------------------

function le.zlecenia.setup_aliases()
    le.zlecenia.aliases = le.zlecenia.aliases or {}
    le.zlecenia.aliases.help = tempAlias("^/le\\.zlecenia$", [[le.zlecenia.show_help()]])
    le.zlecenia.aliases.window = tempAlias("^/le\\.zlecenia okno$", [[le.zlecenia.UI.recover_window()]])
    le.zlecenia.aliases.list = tempAlias("^/le\\.zlecenia lista$", [[le.zlecenia.show_list()]])
    le.zlecenia.aliases.check = tempAlias("^/le\\.zlecenia sprawdz$", [[
        send("zapytaj mezczyzne o zlecenie", false)
        send("zapytaj kobiete o zlecenie", false)
    ]])
    le.zlecenia.aliases.remove = tempAlias("^/le\\.zlecenia usun (\\d+)$", [[le.zlecenia.remove_by_index(tonumber(matches[2]))]])
    le.zlecenia.aliases.reset = tempAlias("^/le\\.zlecenia reset$", [[le.zlecenia.reset_all()]])
    le.zlecenia.aliases.learn = tempAlias("^/le\\.zlecenia slowo (.+)$", [[le.zlecenia.learn_word_manual(matches[2])]])
end

function le.zlecenia.learn_word_manual(word)
    word = word:lower():gsub("%s+", "")
    if word == "" then return end
    le.zlecenia.data.vocab = le.zlecenia.data.vocab or {}
    le.zlecenia.data.vocab[word] = true
    le.zlecenia.save()
    le.zlecenia.output(string.format("Dodano %s do słownika gnomiej mowy.", dc(le.zlecenia.config.colors.good, word)))
end

-- Cykl życia ----------------------------------------------------------------

function le.zlecenia.UI.destroy()
    -- Zwykle hide() nie niszczy etykiet ani ich natywnych callbackow.
    -- Po aktualizacji skryptu powodowalo to martwe/zaslaniajace klikniecia.
    local ui = le.zlecenia.UI
    local labels = { ui.header, ui.footer }
    for _, group in ipairs({ ui.pool or {}, ui.routeBtn or {}, ui.deleteBtn or {}, ui.nav or {} }) do
        for _, label in ipairs(group) do labels[#labels + 1] = label end
    end
    for _, label in ipairs(labels) do
        if label then
            if type(label.delete) == "function" then
                pcall(label.delete, label)
            elseif type(label.hide) == "function" then
                pcall(label.hide, label)
            end
        end
    end
    if ui.window then
        if type(saveWindowLayout) == "function" then pcall(saveWindowLayout) end
        if type(ui.window.delete) == "function" then
            ui.window:delete()
        elseif type(ui.window.type_delete) == "function" then
            ui.window:type_delete()
        end
    end
    ui.header, ui.footer, ui.window = nil, nil, nil
    ui.pool, ui.routeBtn, ui.deleteBtn, ui.slotOrder = nil, nil, nil, nil
    ui.mode, ui.visible, ui.nav = nil, nil, nil
end

function le.zlecenia.cleanup()
    if le.zlecenia.timer then pcall(killTimer, le.zlecenia.timer); le.zlecenia.timer = nil end
    if le.zlecenia.exit_handler then pcall(killAnonymousEventHandler, le.zlecenia.exit_handler); le.zlecenia.exit_handler = nil end
    if le.zlecenia.aliases then for _, id in pairs(le.zlecenia.aliases) do pcall(killAlias, id) end end
    if le.zlecenia.triggers then for _, id in pairs(le.zlecenia.triggers) do pcall(killTrigger, id) end end
    le.zlecenia.UI.destroy()
    if le.zlecenia.UI.routingKey then pcall(alias_func_prowadz_stop) end
    le.zlecenia.UI.routingKey = nil
    end

function le.zlecenia.init()
    le.zlecenia.cleanup()
    le.zlecenia.load()
    le.zlecenia.setup_triggers()
    le.zlecenia.setup_aliases()
    le.zlecenia.exit_handler = registerAnonymousEventHandler("sysExitEvent", le.zlecenia.save)
    le.zlecenia.timer = tempTimer(le.zlecenia.config.check_interval, function()
        le.zlecenia.check_expired()
        le.zlecenia.UI.rebuild()
    end, true)
    le.zlecenia.UI.rebuild()
    le.zlecenia.output("Moduł zleceń załadowany · /le.zlecenia")
end

le.zlecenia.init()

